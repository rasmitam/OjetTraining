/**
  Copyright (c) 2015, 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
(function ($)
{
  QUnit.module("composite component");
  QUnit.test("example test", function (assert)
  {
    var done = assert.async();
    assert.expect(1);
    assert.ok(true);
    done();
  });
})(jQuery);