define(['ojs/ojcore', 'knockout', 'jquery',
  'ojs/ojnavigationlist', 'ojs/ojrouter', 'ojs/ojmodule'],
 function(oj, ko, $) {
  
    function AdminInvoicesViewModel() {
      var self = this;

      self.connected = function() {
      };

      self.disconnected = function() {
      };

      self.transitionCompleted = function() {
      };
    }
    return AdminInvoicesViewModel();
  }
);
